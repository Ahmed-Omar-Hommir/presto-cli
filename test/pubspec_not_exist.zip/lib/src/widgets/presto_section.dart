import 'package:component_library/component_library.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrestoSection extends StatelessWidget {
  const PrestoSection({
    super.key,
    required this.title,
    this.contentPadding,
    required this.child,
  });

  final Widget child;
  final String title;
  final EdgeInsetsGeometry? contentPadding;

  EdgeInsetsGeometry get _contentPadding {
    if (contentPadding != null) return contentPadding!;

    return EdgeInsets.only(
      left: 16.w,
      right: 16.w,
      top: 16.h,
      bottom: 20.h,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: PrestoColors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 12.h,
              left: 16.w,
              right: 16.w,
            ),
            child: PrestoText(
              title,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          Padding(
            padding: _contentPadding,
            child: child,
          ),
        ],
      ),
    );
  }
}
