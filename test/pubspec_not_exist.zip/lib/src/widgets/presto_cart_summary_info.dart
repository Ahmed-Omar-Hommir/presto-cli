import 'package:component_library/component_library.dart';
import 'package:flutter/material.dart';

class PrestoCartSummaryInfo extends StatelessWidget {
  const PrestoCartSummaryInfo({
    Key? key,
    required this.label,
    required this.value,
  }) : super(key: key);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        PrestoText(
          label,
          style: textTheme.labelLarge?.copyWith(color: PrestoColors.gray500),
        ),
        PrestoText(
          value,
          style: textTheme.labelLarge?.copyWith(),
        ),
      ],
    );
  }
}
