// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'validate_cart_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ValidateCartState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() validatingCart,
    required TResult Function(ValidationEatCartDM validateCart) loaded,
    required TResult Function() tryAgain,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? validatingCart,
    TResult? Function(ValidationEatCartDM validateCart)? loaded,
    TResult? Function()? tryAgain,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? validatingCart,
    TResult Function(ValidationEatCartDM validateCart)? loaded,
    TResult Function()? tryAgain,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ValidatingCart value) validatingCart,
    required TResult Function(Loaded value) loaded,
    required TResult Function(TryAgain value) tryAgain,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ValidatingCart value)? validatingCart,
    TResult? Function(Loaded value)? loaded,
    TResult? Function(TryAgain value)? tryAgain,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ValidatingCart value)? validatingCart,
    TResult Function(Loaded value)? loaded,
    TResult Function(TryAgain value)? tryAgain,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValidateCartStateCopyWith<$Res> {
  factory $ValidateCartStateCopyWith(
          ValidateCartState value, $Res Function(ValidateCartState) then) =
      _$ValidateCartStateCopyWithImpl<$Res, ValidateCartState>;
}

/// @nodoc
class _$ValidateCartStateCopyWithImpl<$Res, $Val extends ValidateCartState>
    implements $ValidateCartStateCopyWith<$Res> {
  _$ValidateCartStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ValidatingCartCopyWith<$Res> {
  factory _$$ValidatingCartCopyWith(
          _$ValidatingCart value, $Res Function(_$ValidatingCart) then) =
      __$$ValidatingCartCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ValidatingCartCopyWithImpl<$Res>
    extends _$ValidateCartStateCopyWithImpl<$Res, _$ValidatingCart>
    implements _$$ValidatingCartCopyWith<$Res> {
  __$$ValidatingCartCopyWithImpl(
      _$ValidatingCart _value, $Res Function(_$ValidatingCart) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ValidatingCart implements ValidatingCart {
  const _$ValidatingCart();

  @override
  String toString() {
    return 'ValidateCartState.validatingCart()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ValidatingCart);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() validatingCart,
    required TResult Function(ValidationEatCartDM validateCart) loaded,
    required TResult Function() tryAgain,
  }) {
    return validatingCart();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? validatingCart,
    TResult? Function(ValidationEatCartDM validateCart)? loaded,
    TResult? Function()? tryAgain,
  }) {
    return validatingCart?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? validatingCart,
    TResult Function(ValidationEatCartDM validateCart)? loaded,
    TResult Function()? tryAgain,
    required TResult orElse(),
  }) {
    if (validatingCart != null) {
      return validatingCart();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ValidatingCart value) validatingCart,
    required TResult Function(Loaded value) loaded,
    required TResult Function(TryAgain value) tryAgain,
  }) {
    return validatingCart(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ValidatingCart value)? validatingCart,
    TResult? Function(Loaded value)? loaded,
    TResult? Function(TryAgain value)? tryAgain,
  }) {
    return validatingCart?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ValidatingCart value)? validatingCart,
    TResult Function(Loaded value)? loaded,
    TResult Function(TryAgain value)? tryAgain,
    required TResult orElse(),
  }) {
    if (validatingCart != null) {
      return validatingCart(this);
    }
    return orElse();
  }
}

abstract class ValidatingCart implements ValidateCartState {
  const factory ValidatingCart() = _$ValidatingCart;
}

/// @nodoc
abstract class _$$LoadedCopyWith<$Res> {
  factory _$$LoadedCopyWith(_$Loaded value, $Res Function(_$Loaded) then) =
      __$$LoadedCopyWithImpl<$Res>;
  @useResult
  $Res call({ValidationEatCartDM validateCart});

  $ValidationEatCartDMCopyWith<$Res> get validateCart;
}

/// @nodoc
class __$$LoadedCopyWithImpl<$Res>
    extends _$ValidateCartStateCopyWithImpl<$Res, _$Loaded>
    implements _$$LoadedCopyWith<$Res> {
  __$$LoadedCopyWithImpl(_$Loaded _value, $Res Function(_$Loaded) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? validateCart = null,
  }) {
    return _then(_$Loaded(
      null == validateCart
          ? _value.validateCart
          : validateCart // ignore: cast_nullable_to_non_nullable
              as ValidationEatCartDM,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ValidationEatCartDMCopyWith<$Res> get validateCart {
    return $ValidationEatCartDMCopyWith<$Res>(_value.validateCart, (value) {
      return _then(_value.copyWith(validateCart: value));
    });
  }
}

/// @nodoc

class _$Loaded implements Loaded {
  const _$Loaded(this.validateCart);

  @override
  final ValidationEatCartDM validateCart;

  @override
  String toString() {
    return 'ValidateCartState.loaded(validateCart: $validateCart)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$Loaded &&
            (identical(other.validateCart, validateCart) ||
                other.validateCart == validateCart));
  }

  @override
  int get hashCode => Object.hash(runtimeType, validateCart);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadedCopyWith<_$Loaded> get copyWith =>
      __$$LoadedCopyWithImpl<_$Loaded>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() validatingCart,
    required TResult Function(ValidationEatCartDM validateCart) loaded,
    required TResult Function() tryAgain,
  }) {
    return loaded(validateCart);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? validatingCart,
    TResult? Function(ValidationEatCartDM validateCart)? loaded,
    TResult? Function()? tryAgain,
  }) {
    return loaded?.call(validateCart);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? validatingCart,
    TResult Function(ValidationEatCartDM validateCart)? loaded,
    TResult Function()? tryAgain,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(validateCart);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ValidatingCart value) validatingCart,
    required TResult Function(Loaded value) loaded,
    required TResult Function(TryAgain value) tryAgain,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ValidatingCart value)? validatingCart,
    TResult? Function(Loaded value)? loaded,
    TResult? Function(TryAgain value)? tryAgain,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ValidatingCart value)? validatingCart,
    TResult Function(Loaded value)? loaded,
    TResult Function(TryAgain value)? tryAgain,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class Loaded implements ValidateCartState {
  const factory Loaded(final ValidationEatCartDM validateCart) = _$Loaded;

  ValidationEatCartDM get validateCart;
  @JsonKey(ignore: true)
  _$$LoadedCopyWith<_$Loaded> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TryAgainCopyWith<$Res> {
  factory _$$TryAgainCopyWith(
          _$TryAgain value, $Res Function(_$TryAgain) then) =
      __$$TryAgainCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TryAgainCopyWithImpl<$Res>
    extends _$ValidateCartStateCopyWithImpl<$Res, _$TryAgain>
    implements _$$TryAgainCopyWith<$Res> {
  __$$TryAgainCopyWithImpl(_$TryAgain _value, $Res Function(_$TryAgain) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TryAgain implements TryAgain {
  const _$TryAgain();

  @override
  String toString() {
    return 'ValidateCartState.tryAgain()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TryAgain);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() validatingCart,
    required TResult Function(ValidationEatCartDM validateCart) loaded,
    required TResult Function() tryAgain,
  }) {
    return tryAgain();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? validatingCart,
    TResult? Function(ValidationEatCartDM validateCart)? loaded,
    TResult? Function()? tryAgain,
  }) {
    return tryAgain?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? validatingCart,
    TResult Function(ValidationEatCartDM validateCart)? loaded,
    TResult Function()? tryAgain,
    required TResult orElse(),
  }) {
    if (tryAgain != null) {
      return tryAgain();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(ValidatingCart value) validatingCart,
    required TResult Function(Loaded value) loaded,
    required TResult Function(TryAgain value) tryAgain,
  }) {
    return tryAgain(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(ValidatingCart value)? validatingCart,
    TResult? Function(Loaded value)? loaded,
    TResult? Function(TryAgain value)? tryAgain,
  }) {
    return tryAgain?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(ValidatingCart value)? validatingCart,
    TResult Function(Loaded value)? loaded,
    TResult Function(TryAgain value)? tryAgain,
    required TResult orElse(),
  }) {
    if (tryAgain != null) {
      return tryAgain(this);
    }
    return orElse();
  }
}

abstract class TryAgain implements ValidateCartState {
  const factory TryAgain() = _$TryAgain;
}
