import 'package:component_library/component_library.dart';
import 'package:eat_cart/eat_cart.dart';
import 'package:eat_cart/src/logic/eat_cart_bloc.dart';
import 'package:eat_cart/src/widgets/cart_summary.dart';
import 'package:eat_cart/src/widgets/item_list.dart';
import 'package:eat_cart/src/widgets/loading.dart';
import 'package:eat_cart/src/widgets/restaurant_info.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EatCartPage extends StatelessWidget {
  const EatCartPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final loc = EatCartLocalization.of(context);
    final componenLoc = ComponentLocalizations.of(context);
    final bloc = context.read<EatCartBloc>();
    return BlocConsumer<EatCartBloc, EatCartState>(
      listener: (context, state) {
        state.validateCart.maybeMap(
          loaded: (value) {
            value.validateCart.error.fold(
              () => null,
              (dialogData) {
                context.read<EatCartDelegate>().onTapEatCartValidationDialog(
                      context,
                      validationType: dialogData.type,
                      title: dialogData.title,
                      message: dialogData.message,
                    );
              },
            );
            state.confirmOrderState.map(
              openDialog: (_) {
                context
                    .read<EatCartDelegate>()
                    .onTapShowLoadingIndicatorDialog(context);
              },
              closeDialog: (_) {
                context
                    .read<EatCartDelegate>()
                    .onTapHideLoadingIndicatorDialog();
              },
              confirmed: (_) {
                state.cart.maybeMap(
                  loaded: (value) {
                    final cart = value.cart;
                    cart.fold(
                      () => null,
                      (value) {
                        // Todo: remove parameters after refactor chechout page
                        context.read<EatCartDelegate>().onTapEatCartDetails(
                            eatCart: value);
                      },
                    );
                  },
                  orElse: () => null,
                );
              },
              nothing: (_) => null,
            );
          },
          orElse: () => null,
        );
      },
      builder: (context, state) {
        final textTheme = Theme.of(context).textTheme;
        return Scaffold(
          appBar: PrestoAppBar(
            centerTitle: false,
            title: PrestoText(
              loc.appBarTitle,
              style: textTheme.titleMedium?.copyWith(color: PrestoColors.black),
            ),
          ),
          body: state.cart.map(
            fetchingCart: (_) => const EatCartLoading(),
            loaded: (value) {
              return value.cart.fold(
                () {
                  return PrestoEmptyCart(
                    title: loc.emptyCartTitle,
                    subtitle: loc.emptyCartSubtitle,
                    titleButton: loc.emptyCartButton,
                    onPressed: () {
                      bloc.eatMainLayoutServices.openRestaurantExplorer();
                      context
                          .read<EatCartDelegate>()
                          .onTapRestaurantsDiscovery();
                    },
                  );
                },
                (cart) {
                  return state.validateCart.map(
                    validatingCart: (value) => const EatCartLoading(),
                    loaded: (value) {
                      return OpacityAnimation(
                        child: Column(
                          children: [
                            Expanded(
                              child: ListView(
                                children: [
                                  SizedBox(height: 1.h),
                                  state.validateCart.maybeMap(
                                    loaded: (value) {
                                      return RestaurantInfo(
                                        restaurant:
                                            value.validateCart.restaurant,
                                      );
                                    },
                                    orElse: () => const SizedBox.shrink(),
                                  ),
                                  SizedBox(height: 4.h),
                                  ItemList(cart: cart),
                                  SizedBox(height: 4.h),
                                  CartSummary(
                                    totalQuantity: cart.items.totalQuantity,
                                    totalPriceOfItems:
                                        cart.items.totalItemsPrice,
                                    deliveryCharge:
                                        cart.restaurant.deliveryCharge,
                                    totalPriceOfOrder: cart.totalCart,
                                  ),
                                  SizedBox(height: 20.h),
                                ],
                              ),
                            ),
                            BottomFloatingContainer(
                              child: PrestoSuperButton(
                                centerWidget:
                                    PrestoText(loc.confirmOrderButton),
                                endWidget: PrestoText(componenLoc
                                    .lyd(cart.totalCart.moneyFormate())),
                                onPressed: () {
                                  bloc.add(SubmitCartEvent(cart));
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                    tryAgain: (_) {
                      return PrestoFailure(onPressed: () {
                        bloc.add(ValidateCartEvent(cart));
                      });
                    },
                  );
                },
              );
            },
            tryAgain: (_) {
              return PrestoFailure(onPressed: () {
                bloc.add(GetCartLocalEvent());
              });
            },
          ),
        );
      },
    );
  }
}

class OpacityAnimation extends StatefulWidget {
  const OpacityAnimation({
    super.key,
    required this.child,
  });

  final Widget child;

  @override
  State<OpacityAnimation> createState() => _OpacityAnimationState();
}

class _OpacityAnimationState extends State<OpacityAnimation> {
  double opacity = 0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        opacity = 1;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: opacity,
      duration: const Duration(milliseconds: 160),
      curve: Curves.linear,
      child: widget.child,
    );
  }
}
