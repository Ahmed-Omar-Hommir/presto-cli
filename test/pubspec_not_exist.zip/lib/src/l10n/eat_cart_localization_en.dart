import 'eat_cart_localization.dart';

/// The translations for English (`en`).
class EatCartLocalizationEn extends EatCartLocalization {
  EatCartLocalizationEn([String locale = 'en']) : super(locale);

  @override
  String get editAddressButton => 'Edit';

  @override
  String get itemListLabel => 'Order Items';

  @override
  String get itemUnavailable => 'Unavailable';

  @override
  String get summary => 'Summary';

  @override
  String get deliveryPrice => 'Delivery Charge';

  @override
  String get itemsPrice => 'Items Price';

  @override
  String get total => 'Total';

  @override
  String get confirmOrderButton => 'Checkout';

  @override
  String get emptyCartTitle => 'Your Cart is Empty';

  @override
  String get emptyCartSubtitle => 'Fill up your cart from your favorite restaurant';

  @override
  String get emptyCartButton => 'Discover Restaurants';

  @override
  String get appBarTitle => 'Cart';

  @override
  String get twoItem => 'two Items';

  @override
  String get items => 'Items';

  @override
  String get item => 'item';

  @override
  String get oneItem => 'one Item';

  @override
  String get confirmDeleteItem => 'Delete';

  @override
  String get discardDeleteItem => 'Cancel';

  @override
  String deleteItemTitle(String name) {
    return 'Do you really want to remove \"$name\"?';
  }

  @override
  String get yourOrderFrom => 'Your Order From';

  @override
  String lyd(Object value) {
    return '$value د.ل';
  }

  @override
  String get addItems => 'Add Items';
}
