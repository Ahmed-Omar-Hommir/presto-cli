import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'eat_cart_localization_ar.dart';
import 'eat_cart_localization_en.dart';

/// Callers can lookup localized strings with an instance of EatCartLocalization
/// returned by `EatCartLocalization.of(context)`.
///
/// Applications need to include `EatCartLocalization.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/eat_cart_localization.dart';
///
/// return MaterialApp(
///   localizationsDelegates: EatCartLocalization.localizationsDelegates,
///   supportedLocales: EatCartLocalization.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the EatCartLocalization.supportedLocales
/// property.
abstract class EatCartLocalization {
  EatCartLocalization(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static EatCartLocalization of(BuildContext context) {
    return Localizations.of<EatCartLocalization>(context, EatCartLocalization)!;
  }

  static const LocalizationsDelegate<EatCartLocalization> delegate = _EatCartLocalizationDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @editAddressButton.
  ///
  /// In ar, this message translates to:
  /// **'تعديل'**
  String get editAddressButton;

  /// No description provided for @itemListLabel.
  ///
  /// In ar, this message translates to:
  /// **'عناصر الطلب'**
  String get itemListLabel;

  /// No description provided for @itemUnavailable.
  ///
  /// In ar, this message translates to:
  /// **'غير متاح'**
  String get itemUnavailable;

  /// No description provided for @summary.
  ///
  /// In ar, this message translates to:
  /// **'الملخص'**
  String get summary;

  /// No description provided for @deliveryPrice.
  ///
  /// In ar, this message translates to:
  /// **'سعر التوصيل'**
  String get deliveryPrice;

  /// No description provided for @itemsPrice.
  ///
  /// In ar, this message translates to:
  /// **'سعر العناصر'**
  String get itemsPrice;

  /// No description provided for @total.
  ///
  /// In ar, this message translates to:
  /// **'الإجمالي'**
  String get total;

  /// No description provided for @confirmOrderButton.
  ///
  /// In ar, this message translates to:
  /// **'تأكيد الطلب'**
  String get confirmOrderButton;

  /// No description provided for @emptyCartTitle.
  ///
  /// In ar, this message translates to:
  /// **'السلة فارغة'**
  String get emptyCartTitle;

  /// No description provided for @emptyCartSubtitle.
  ///
  /// In ar, this message translates to:
  /// **'املأ السلة من مطعمك المفضل'**
  String get emptyCartSubtitle;

  /// No description provided for @emptyCartButton.
  ///
  /// In ar, this message translates to:
  /// **'استكشف المطاعم'**
  String get emptyCartButton;

  /// No description provided for @appBarTitle.
  ///
  /// In ar, this message translates to:
  /// **'السلة'**
  String get appBarTitle;

  /// No description provided for @twoItem.
  ///
  /// In ar, this message translates to:
  /// **'عنصرين'**
  String get twoItem;

  /// No description provided for @items.
  ///
  /// In ar, this message translates to:
  /// **'عناصر'**
  String get items;

  /// No description provided for @item.
  ///
  /// In ar, this message translates to:
  /// **'عنصر'**
  String get item;

  /// No description provided for @oneItem.
  ///
  /// In ar, this message translates to:
  /// **'عنصر واحد'**
  String get oneItem;

  /// No description provided for @confirmDeleteItem.
  ///
  /// In ar, this message translates to:
  /// **'حذف'**
  String get confirmDeleteItem;

  /// No description provided for @discardDeleteItem.
  ///
  /// In ar, this message translates to:
  /// **'إلغاء'**
  String get discardDeleteItem;

  /// No description provided for @deleteItemTitle.
  ///
  /// In ar, this message translates to:
  /// **'هل تود حقاً حذف “{name}”؟'**
  String deleteItemTitle(String name);

  /// No description provided for @yourOrderFrom.
  ///
  /// In ar, this message translates to:
  /// **'طلبك من'**
  String get yourOrderFrom;

  /// No description provided for @lyd.
  ///
  /// In ar, this message translates to:
  /// **'{value} د.ل'**
  String lyd(Object value);

  /// No description provided for @addItems.
  ///
  /// In ar, this message translates to:
  /// **'إضافة عناصر'**
  String get addItems;
}

class _EatCartLocalizationDelegate extends LocalizationsDelegate<EatCartLocalization> {
  const _EatCartLocalizationDelegate();

  @override
  Future<EatCartLocalization> load(Locale locale) {
    return SynchronousFuture<EatCartLocalization>(lookupEatCartLocalization(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_EatCartLocalizationDelegate old) => false;
}

EatCartLocalization lookupEatCartLocalization(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return EatCartLocalizationAr();
    case 'en': return EatCartLocalizationEn();
  }

  throw FlutterError(
    'EatCartLocalization.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
