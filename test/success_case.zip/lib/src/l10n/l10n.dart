export 'eat_cart_localization.dart';
