import 'package:domain_models/domain_models.dart';
import 'package:flutter/cupertino.dart';

abstract class EatCartDelegate {
  void onTapRestaurantsDiscovery();

  // Todo: remove parameters after refactor chechout page
  void onTapEatCartDetails({
    required EatCartDM eatCart,
  });
  Future<void> onTapHideLoadingIndicatorDialog();
  Future<void> onTapShowLoadingIndicatorDialog(BuildContext context);
  void onTapEatCartChangeAddressPage(BuildContext context);
  void onTapUpdateItemCart(EatCartItemDM item);
  onTapEatCartValidationDialog(
    BuildContext context, {
    required String validationType,
    required String title,
    required String message,
  });
  void onTapAddItemsFromEatCart(
    BuildContext context, {
    required String tag,
    required RestaurantDM restaurant,
  });
}
