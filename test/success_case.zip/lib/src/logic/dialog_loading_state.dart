import 'package:freezed_annotation/freezed_annotation.dart';

part 'dialog_loading_state.freezed.dart';

@freezed
class ConfirmOrderState with _$ConfirmOrderState {
  const factory ConfirmOrderState.openDialog() = OpenDialog;
  const factory ConfirmOrderState.closeDialog() = CloseDialog;
  const factory ConfirmOrderState.nothing() = Nothing;
  const factory ConfirmOrderState.confirmed() = Confirmed;
}
