import 'package:address_repository/address_repository.dart';
import 'package:domain_models/domain_models.dart';
import 'package:eat_cart/src/logic/cart_address_events.dart';
import 'package:eat_cart/src/logic/cart_address_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class EatCartAddressBloc extends Bloc<CartAddressEvents, CartAddressState> {
  EatCartAddressBloc({
    required AddressRepository addressRepository,
  }) : super(CartAddressState()) {
    PagingController<int, AddressModel> pagingController =
        PagingController<int, AddressModel>(firstPageKey: 1);
    on<GetAddressesEvent>((event, emit) async {
      final eitherResponse =
          await addressRepository.getAddress(event.pageNumber);
      eitherResponse.fold(
        (failure) => pagingController.error = failure,
        (response) {
          if (response.isLastPage) {
            pagingController.appendLastPage(response.addresses);
          } else {
            final nextPageKey = event.pageNumber + 1;
            pagingController.appendPage(response.addresses, nextPageKey);
          }

          emit(
            state.copyWith(
              addresses: AddressList(
                addresses: pagingController.itemList ?? [],
                isLastPage: response.isLastPage,
              ),
            ),
          );
        },
      );
    });
    on<SelectAddressEvent>((event, emit) {
      final addresses = state.addresses.setDefaultAddress(event.addressId);
      pagingController.itemList = addresses;
      emit(
        state.copyWith(
          addresses: state.addresses.copyWith(addresses: addresses),
        ),
      );
    });
    on<SubmitAddressEvent>((event, emit) async {
      final defaultAddress = state.addresses.getDefaultAddress();
      if (defaultAddress != null) {
        final eitherResponse =
            await addressRepository.setDefaultAddress(defaultAddress.id);
        eitherResponse.fold(
          (failure) => null,
          (response) => null,
        );
      }
    });
    _pagingController = pagingController;
    pagingController.addPageRequestListener((pageKey) async {
      add(GetAddressesEvent(pageKey));
    });
  }
  late final PagingController<int, AddressModel> _pagingController;
  PagingController<int, AddressModel> get pagingController => _pagingController;
}
