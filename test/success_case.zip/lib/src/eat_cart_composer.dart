import 'package:eat_cart/src/eat_cart_delegate.dart';
import 'package:eat_cart/src/eat_cart_page.dart';
import 'package:eat_cart/src/logic/eat_cart_bloc.dart';
import 'package:eat_cart_repository/eat_cart_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:restaurant_repository/restaurant_repository.dart';

abstract class EatCartComposer {
  static Widget composeCartPage({
    required EatCartRepository eatCartRepository,
    required EatCartDelegate eatCartDelegate,
    required IEatMainLayoutServices eatMainLayoutServices,
  }) {
    return BlocProvider(
      create: (context) => EatCartBloc(
        cartRepository: eatCartRepository,
        eatMainLayoutServices: eatMainLayoutServices,
      ),
      child: MultiRepositoryProvider(
        providers: [
          RepositoryProvider(
            create: (context) => eatCartDelegate,
          ),
        ],
        child: const EatCartPage(),
      ),
    );
  }
}
