import 'dart:ui';
import 'package:component_library/component_library.dart';
import 'package:domain_models/domain_models.dart';
import 'package:eat_cart/eat_cart.dart';
import 'package:eat_cart/src/logic/eat_cart_bloc.dart';
import 'package:eat_cart/src/widgets/item_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CartItem extends StatelessWidget {
  const CartItem({
    Key? key,
    required this.cartItem,
  }) : super(key: key);

  final EatCartItemDM cartItem;

  @override
  Widget build(BuildContext context) {
    final loc = EatCartLocalization.of(context);
    final componenLoc = ComponentLocalizations.of(context);

    final eatCartBloc = context.read<EatCartBloc>();
    final double opacity = cartItem.isOpen ? 1 : .5;
    final textTheme = Theme.of(context).textTheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            ItemImage(
              imageUrl: cartItem.image,
              isItemAvailable: cartItem.isOpen,
              width: 62,
              height: 58,
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.only(end: 16.h),
                          child: Opacity(
                            opacity: opacity,
                            child: PrestoText(
                              cartItem.name,
                              overflow: TextOverflow.ellipsis,
                              style: textTheme.titleMedium,
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          PrestoDialogBuilder(
                            context,
                            builder: (_) {
                              return PrestoAlertDialog(
                                content: PrestoText(
                                  loc.deleteItemTitle(cartItem.name),
                                  style:
                                      Theme.of(context).textTheme.titleMedium,
                                ),
                                actions: [
                                  PrestoActionDialog(
                                    text: loc.discardDeleteItem,
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  PrestoActionDialog(
                                    text: loc.confirmDeleteItem,
                                    onPressed: () {
                                      eatCartBloc
                                          .add(DeleteItemEvent(cartItem));
                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                              );
                            },
                          ).show();
                        },
                        child: Container(
                          width: 24.w,
                          height: 24.w,
                          decoration: BoxDecoration(
                            color: cartItem.isOpen
                                ? PrestoColors.gray100
                                : PrestoColors.error200,
                            borderRadius: BorderRadius.circular(24.r),
                          ),
                          child: Icon(
                            PhosphorIcons.trash_simple_bold,
                            size: 16.sp,
                            color: cartItem.isOpen
                                ? PrestoColors.gray400
                                : PrestoColors.error400,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      PrestoExpandedQuantityChanger(
                        disable: !cartItem.isOpen,
                        quantity: cartItem.quantity,
                        onIncreaseQuantity: (increasedQuantity) {
                          eatCartBloc.add(
                            ChangeQuantityEvent(
                              item: cartItem,
                              newQuantity: increasedQuantity,
                            ),
                          );
                        },
                        onDecreaseQuantity: (decreasedQuantity) {
                          eatCartBloc.add(
                            ChangeQuantityEvent(
                              item: cartItem,
                              newQuantity: decreasedQuantity,
                            ),
                          );
                        },
                      ),
                      Opacity(
                        opacity: opacity,
                        child: PrestoText(
                          componenLoc.lyd(cartItem.totalPrice.moneyFormate()),
                          style: textTheme.labelLarge?.copyWith(
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        if (!cartItem.isOpen) const ItemError(),
      ],
    );
  }
}
