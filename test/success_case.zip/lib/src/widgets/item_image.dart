import 'package:component_library/component_library.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ItemImage extends StatelessWidget {
  const ItemImage({
    Key? key,
    required this.isItemAvailable,
    required this.imageUrl,
    required this.height,
    required this.width,
  }) : super(key: key);
  final bool isItemAvailable;
  final String imageUrl;
  final double height;
  final double width;

  @override
  Widget build(BuildContext context) {
    final double opacity = isItemAvailable ? 1 : .5;

    return Container(
      clipBehavior: Clip.hardEdge,
      width: width.w,
      height: height.h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Opacity(
        opacity: opacity,
        child: PrestoCachedNetworkImage(imageUrl: imageUrl),
      ),
    );
  }
}
