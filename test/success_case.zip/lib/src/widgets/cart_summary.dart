import 'package:component_library/component_library.dart';
import 'package:eat_cart/eat_cart.dart';
import 'package:eat_cart/src/widgets/presto_cart_summary_info.dart' as info;
import 'package:eat_cart/src/widgets/presto_section.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CartSummary extends StatelessWidget {
  const CartSummary(
      {Key? key,
      required this.totalPriceOfItems,
      required this.deliveryCharge,
      required this.totalPriceOfOrder,
      required this.totalQuantity})
      : super(key: key);
  final double totalPriceOfItems;
  final double deliveryCharge;
  final double totalPriceOfOrder;
  final int totalQuantity;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final loc = EatCartLocalization.of(context);
    final componenLoc = ComponentLocalizations.of(context);

    return PrestoSection(
      title: loc.summary,
      contentPadding: EdgeInsets.only(
        top: 2.h,
        left: 16.w,
        right: 16.w,
        bottom: 20.h,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PrestoText(
            totalQuantity.label(context),
            style: textTheme.bodySmall?.copyWith(color: PrestoColors.gray400),
          ),
          SizedBox(height: 16.h),
          info.PrestoCartSummaryInfo(
            label: loc.itemsPrice,
            value: componenLoc.lyd(totalPriceOfItems.moneyFormate()),
          ),
          SizedBox(height: 12.h),
          const PrestoDivider(),
          SizedBox(height: 12.h),
          info.PrestoCartSummaryInfo(
            label: loc.deliveryPrice,
            value: componenLoc.lyd(deliveryCharge.moneyFormate()),
          ),
          SizedBox(height: 12.h),
          const PrestoDivider(),
          SizedBox(height: 12.h),
          info.PrestoCartSummaryInfo(
            label: loc.total,
            value: componenLoc.lyd(totalPriceOfOrder.moneyFormate()),
          ),
        ],
      ),
    );
  }
}
