import 'package:component_library/component_library.dart';
import 'package:domain_models/domain_models.dart';
import 'package:eat_cart/eat_cart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RestaurantInfo extends StatelessWidget {
  const RestaurantInfo({
    super.key,
    required this.restaurant,
  });

  final RestaurantDM restaurant;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final loc = EatCartLocalization.of(context);
    return Container(
      padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 16.w),
      color: PrestoColors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                PrestoText(
                  EatCartLocalization.of(context).yourOrderFrom,
                  style: textTheme.labelMedium?.copyWith(
                    color: PrestoColors.gray400,
                  ),
                ),
                PrestoText(
                  restaurant.name,
                  style: textTheme.titleMedium,
                  overflow: TextOverflow.visible,
                ),
              ],
            ),
          ),
          SizedBox(width: 6.w),
          InkWell(
            onTap: () {
              context.read<EatCartDelegate>().onTapAddItemsFromEatCart(
                    context,
                    tag: '',
                    restaurant: restaurant,
                  );
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                vertical: 8.h,
                horizontal: 8.w,
              ),
              decoration: BoxDecoration(
                color: PrestoColors.primary100,
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Row(
                children: [
                  Icon(
                    PhosphorIcons.plus_bold,
                    color: PrestoColors.primary500,
                    size: 16.w,
                  ),
                  SizedBox(width: 4.w),
                  PrestoText(
                    loc.addItems,
                    style: textTheme.labelMedium?.copyWith(
                      color: PrestoColors.primary500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
