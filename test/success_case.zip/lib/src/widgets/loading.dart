import 'package:component_library/component_library.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EatCartLoading extends StatelessWidget {
  const EatCartLoading({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const PrestoDivider(),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.only(
                    left: 16.w,
                    right: 16.w,
                    top: 12.h,
                    bottom: 16.h,
                  ),
                  width: double.infinity,
                  color: PrestoColors.white,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PrestoShimmer.rectangular(
                            width: 120,
                            height: 16,
                            borderRadius: BorderRadius.circular(4.r),
                          ),
                          SizedBox(height: 6.h),
                          PrestoShimmer.rectangular(
                            width: 200,
                            height: 20,
                            borderRadius: BorderRadius.circular(4.r),
                          ),
                        ],
                      ),
                      PrestoShimmer.rectangular(
                        width: 90,
                        height: 32,
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 4.h),
                PrestoListGenerator(
                  listHeightPercentage: .62,
                  separatorItem: const PrestoDivider(),
                  item: Container(
                    color: PrestoColors.white,
                    height: 104.h,
                    width: double.infinity,
                    padding: EdgeInsets.all(16.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        PrestoShimmer.rectangular(
                          height: 58,
                          width: 62,
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            PrestoShimmer.rectangular(
                              borderRadius: BorderRadius.circular(4.r),
                              width: 214,
                              height: 16,
                            ),
                            SizedBox(height: 12.h),
                            PrestoShimmer.rectangular(
                              borderRadius: BorderRadius.circular(23.r),
                              width: 98,
                              height: 34,
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            PrestoShimmer.circular(radius: 24.r),
                            SizedBox(height: 12.h),
                            PrestoShimmer.rectangular(
                              borderRadius: BorderRadius.circular(4.r),
                              width: 40.w,
                              height: 16.h,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 24.h),
              ],
            ),
          ),
        ),
        BottomFloatingContainer(
          child: PrestoShimmer.rectangular(
            width: double.infinity,
            height: 48,
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
      ],
    );
  }
}
