import 'package:eat_cart/eat_cart.dart';
import 'package:flutter/material.dart';

extension EatOrderItemsLabel on num {
  String label(BuildContext context) {
    final local = EatCartLocalization.of(context);
    if (EatCartLocalization.of(context).localeName == "ar") {
      if (this == 1) {
        return local.oneItem;
      }
      if (this == 2) {
        return local.twoItem;
      }
      if (this >= 3 && this <= 10) {
        return '$this ${local.items}';
      }
      return '$this ${local.item}';
    } else {
      if (this == 1) {
        return '$this ${local.item}';
      } else {
        return '$this ${local.items}';
      }
    }
  }
}
