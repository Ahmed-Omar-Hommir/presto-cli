import 'eat_cart_localization.dart';

/// The translations for Arabic (`ar`).
class EatCartLocalizationAr extends EatCartLocalization {
  EatCartLocalizationAr([String locale = 'ar']) : super(locale);

  @override
  String get editAddressButton => 'تعديل';

  @override
  String get itemListLabel => 'عناصر الطلب';

  @override
  String get itemUnavailable => 'غير متاح';

  @override
  String get summary => 'الملخص';

  @override
  String get deliveryPrice => 'سعر التوصيل';

  @override
  String get itemsPrice => 'سعر العناصر';

  @override
  String get total => 'الإجمالي';

  @override
  String get confirmOrderButton => 'تأكيد الطلب';

  @override
  String get emptyCartTitle => 'السلة فارغة';

  @override
  String get emptyCartSubtitle => 'املأ السلة من مطعمك المفضل';

  @override
  String get emptyCartButton => 'استكشف المطاعم';

  @override
  String get appBarTitle => 'السلة';

  @override
  String get twoItem => 'عنصرين';

  @override
  String get items => 'عناصر';

  @override
  String get item => 'عنصر';

  @override
  String get oneItem => 'عنصر واحد';

  @override
  String get confirmDeleteItem => 'حذف';

  @override
  String get discardDeleteItem => 'إلغاء';

  @override
  String deleteItemTitle(String name) {
    return 'هل تود حقاً حذف “$name”؟';
  }

  @override
  String get yourOrderFrom => 'طلبك من';

  @override
  String lyd(Object value) {
    return '$value د.ل';
  }

  @override
  String get addItems => 'إضافة عناصر';
}
