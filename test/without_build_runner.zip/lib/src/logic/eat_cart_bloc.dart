import 'dart:async';

import 'package:bloc_concurrency/bloc_concurrency.dart';
import 'package:dartz/dartz.dart';
import 'package:domain_models/domain_models.dart';
import 'package:eat_cart/src/logic/cart_state.dart';
import 'package:eat_cart/src/logic/dialog_loading_state.dart';
import 'package:eat_cart/src/logic/validate_cart_state.dart';
import 'package:eat_cart_repository/eat_cart_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:restaurant_repository/restaurant_repository.dart';

part './eat_cart_events.dart';

part './eat_cart_state.dart';

part 'eat_cart_bloc.freezed.dart';

class EatCartBloc extends Bloc<EatCartEvents, EatCartState> {
  EatCartBloc({
    required EatCartRepository cartRepository,
    required this.eatMainLayoutServices,
  }) : super(EatCartState()) {
    on<ChangeQuantityEvent>((event, emit) async {
      if (event.newQuantity > 0) {
        await cartRepository.updateItem(
          uniqueKey: event.item.uniqueKey,
          updatedItem: event.item.copyWith(quantity: event.newQuantity),
        );
      } else {
        await cartRepository.deleteItem(event.item);
      }
    });
    on<DeleteItemEvent>(
      (event, emit) async {
        await cartRepository.deleteItem(event.item);
      },
      transformer: droppable(),
    );

    on<GetCartLocalEvent>((event, emit) async {
      emit(state.copyWith(cart: const CartState.fetchingCart()));
      final eitherResponse = await cartRepository.getCart();
      await eitherResponse.fold(
        (_) {
          emit(state.copyWith(cart: const CartState.tryAgain()));
        },
        (cart) async {
          if (cart == null) {
            emit(state.copyWith(cart: CartState.loaded(none())));
          } else {
            emit(
              state.copyWith(cart: CartState.loaded(some(cart))),
            );
            state.validateCart.maybeMap(
              loaded: (_) => null,
              orElse: () => add(ValidateCartEvent(cart)),
            );
          }
        },
      );
    });

    on<ValidateCartEvent>(
      (event, emit) async {
        emit(
          state.copyWith(
              validateCart: const ValidateCartState.validatingCart()),
        );

        final eitherResponse = await cartRepository.validateCart(
          eatCart: event.cart,
          eatValidationRules: ['price_changed'],
        );
        eitherResponse.fold(
          (failure) {
            emit(
              state.copyWith(validateCart: const ValidateCartState.tryAgain()),
            );
          },
          (response) {
            response;
            emit(
              state.copyWith(validateCart: ValidateCartState.loaded(response)),
            );
            emit(
              state.copyWith(
                validateCart: ValidateCartState.loaded(
                  response.copyWith(
                    error: const None(),
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    on<SubmitCartEvent>(
      (event, emit) async {
        emit(state.copyWith(
            confirmOrderState: const ConfirmOrderState.openDialog()));
        emit(state.copyWith(
            confirmOrderState: const ConfirmOrderState.nothing()));
        final eitherResponse = await cartRepository.validateCart(
          eatCart: event.cart,
          eatValidationRules: [],
        );

        eitherResponse.fold(
          (failure) {
            emit(
              state.copyWith(
                confirmOrderState: const ConfirmOrderState.closeDialog(),
              ),
            );
            emit(
              state.copyWith(
                confirmOrderState: const ConfirmOrderState.nothing(),
              ),
            );
            emit(
              state.copyWith(
                validateCart: const ValidateCartState.tryAgain(),
              ),
            );
          },
          (response) {
            emit(
              state.copyWith(
                confirmOrderState: const ConfirmOrderState.closeDialog(),
              ),
            );
            emit(
              state.copyWith(
                confirmOrderState: const ConfirmOrderState.nothing(),
              ),
            );
            emit(
              state.copyWith(
                validateCart: ValidateCartState.loaded(response),
              ),
            );
            emit(
              state.copyWith(
                validateCart: ValidateCartState.loaded(
                  response.copyWith(error: const None()),
                ),
              ),
            );
            response.error.fold(
              () {
                emit(
                  state.copyWith(
                    confirmOrderState: const ConfirmOrderState.confirmed(),
                  ),
                );
                emit(
                  state.copyWith(
                    confirmOrderState: const ConfirmOrderState.nothing(),
                  ),
                );
              },
              (_) => null,
            );
          },
        );
      },
    );

    on<EmptyCartEvent>((event, emit) async {
      await cartRepository.putCart(null);
      emit(state.copyWith(cart: const CartState.loaded(None())));
    });
    subscription = cartRepository.subscription.listen((event) {
      add(GetCartLocalEvent());
    });
    add(GetCartLocalEvent());
  }

  final IEatMainLayoutServices eatMainLayoutServices;

  late final StreamSubscription subscription;

  @override
  Future<void> close() {
    subscription.cancel();
    return super.close();
  }
}

abstract class ValidationType {
  static const String restaurantClosed = 'restaurant.closed';
  static const String restaurantInactive = 'restaurant.inactive';
  static const String cartLessThanMinAmount = 'cart.less_than_min_amount';
  static const String restaurantBusy = 'restaurant.busy';
  static const String restaurantBreak = 'restaurant.break';
  static const String hubBlocked = 'hub.blocked';
  static const String cartUnavailableItems = 'cart.unavailable_items';
  static const String addressUnsupportedLocation =
      'address.unsupported_location';
  static const String userHasAnActiveOrder = 'user.has_an_active_order';
}
