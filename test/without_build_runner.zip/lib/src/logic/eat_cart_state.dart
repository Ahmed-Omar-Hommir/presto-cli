part of './eat_cart_bloc.dart';

@freezed
class EatCartState with _$EatCartState {
  factory EatCartState({
    @Default(CartState.fetchingCart()) CartState cart,
    @Default(ValidateCartState.validatingCart()) ValidateCartState validateCart,
    @Default(ConfirmOrderState.nothing()) ConfirmOrderState confirmOrderState,
  }) = _EatCartState;
}
