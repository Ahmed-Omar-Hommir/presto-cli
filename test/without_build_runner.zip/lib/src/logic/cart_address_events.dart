abstract class CartAddressEvents {}

class GetAddressesEvent extends CartAddressEvents {
  GetAddressesEvent(this.pageNumber);
  final int pageNumber;
}

class SelectAddressEvent extends CartAddressEvents {
  SelectAddressEvent(this.addressId);
  final int addressId;
}

class SubmitAddressEvent extends CartAddressEvents {}
