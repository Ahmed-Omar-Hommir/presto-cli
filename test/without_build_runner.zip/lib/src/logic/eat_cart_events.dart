part of './eat_cart_bloc.dart';

abstract class EatCartEvents {}

class ChangeQuantityEvent extends EatCartEvents {
  ChangeQuantityEvent({
    required this.item,
    required this.newQuantity,
  });

  final EatCartItemDM item;
  final int newQuantity;
}

class GetCartLocalEvent extends EatCartEvents {}

class ValidateCartEvent extends EatCartEvents {
  ValidateCartEvent(this.cart);
  final EatCartDM cart;
}

class SubmitCartEvent extends EatCartEvents {
  SubmitCartEvent(this.cart);
  final EatCartDM cart;
}

class DeleteItemEvent extends EatCartEvents {
  DeleteItemEvent(this.item);

  final EatCartItemDM item;
}

class EmptyCartEvent extends EatCartEvents {}

class HandelValidationEvent extends EatCartEvents {
  HandelValidationEvent(this.validation);
  final ValidationEatCartDM validation;
}
