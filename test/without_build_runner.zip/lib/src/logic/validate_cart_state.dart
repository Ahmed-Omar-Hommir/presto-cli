import 'package:domain_models/domain_models.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'validate_cart_state.freezed.dart';

@freezed
class ValidateCartState with _$ValidateCartState {
  const factory ValidateCartState.validatingCart() = ValidatingCart;
  const factory ValidateCartState.loaded(ValidationEatCartDM validateCart) =
      Loaded;
  const factory ValidateCartState.tryAgain() = TryAgain;
}
