// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'cart_address_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CartAddressState {
  AddressList get addresses => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CartAddressStateCopyWith<CartAddressState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CartAddressStateCopyWith<$Res> {
  factory $CartAddressStateCopyWith(
          CartAddressState value, $Res Function(CartAddressState) then) =
      _$CartAddressStateCopyWithImpl<$Res, CartAddressState>;
  @useResult
  $Res call({AddressList addresses});

  $AddressListCopyWith<$Res> get addresses;
}

/// @nodoc
class _$CartAddressStateCopyWithImpl<$Res, $Val extends CartAddressState>
    implements $CartAddressStateCopyWith<$Res> {
  _$CartAddressStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? addresses = null,
  }) {
    return _then(_value.copyWith(
      addresses: null == addresses
          ? _value.addresses
          : addresses // ignore: cast_nullable_to_non_nullable
              as AddressList,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AddressListCopyWith<$Res> get addresses {
    return $AddressListCopyWith<$Res>(_value.addresses, (value) {
      return _then(_value.copyWith(addresses: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_CartAddressStateCopyWith<$Res>
    implements $CartAddressStateCopyWith<$Res> {
  factory _$$_CartAddressStateCopyWith(
          _$_CartAddressState value, $Res Function(_$_CartAddressState) then) =
      __$$_CartAddressStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({AddressList addresses});

  @override
  $AddressListCopyWith<$Res> get addresses;
}

/// @nodoc
class __$$_CartAddressStateCopyWithImpl<$Res>
    extends _$CartAddressStateCopyWithImpl<$Res, _$_CartAddressState>
    implements _$$_CartAddressStateCopyWith<$Res> {
  __$$_CartAddressStateCopyWithImpl(
      _$_CartAddressState _value, $Res Function(_$_CartAddressState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? addresses = null,
  }) {
    return _then(_$_CartAddressState(
      addresses: null == addresses
          ? _value.addresses
          : addresses // ignore: cast_nullable_to_non_nullable
              as AddressList,
    ));
  }
}

/// @nodoc

class _$_CartAddressState implements _CartAddressState {
  _$_CartAddressState({this.addresses = const AddressList()});

  @override
  @JsonKey()
  final AddressList addresses;

  @override
  String toString() {
    return 'CartAddressState(addresses: $addresses)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CartAddressState &&
            (identical(other.addresses, addresses) ||
                other.addresses == addresses));
  }

  @override
  int get hashCode => Object.hash(runtimeType, addresses);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CartAddressStateCopyWith<_$_CartAddressState> get copyWith =>
      __$$_CartAddressStateCopyWithImpl<_$_CartAddressState>(this, _$identity);
}

abstract class _CartAddressState implements CartAddressState {
  factory _CartAddressState({final AddressList addresses}) =
      _$_CartAddressState;

  @override
  AddressList get addresses;
  @override
  @JsonKey(ignore: true)
  _$$_CartAddressStateCopyWith<_$_CartAddressState> get copyWith =>
      throw _privateConstructorUsedError;
}
