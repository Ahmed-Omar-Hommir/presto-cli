import 'package:dartz/dartz.dart';
import 'package:domain_models/domain_models.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'cart_state.freezed.dart';

@freezed
class CartState with _$CartState {
  const factory CartState.fetchingCart() = FetchingCart;
  const factory CartState.loaded(Option<EatCartDM> cart) = Loaded;
  const factory CartState.tryAgain() = TryAgain;
}
