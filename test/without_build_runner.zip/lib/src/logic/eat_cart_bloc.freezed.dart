// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'eat_cart_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$EatCartState {
  CartState get cart => throw _privateConstructorUsedError;
  ValidateCartState get validateCart => throw _privateConstructorUsedError;
  ConfirmOrderState get confirmOrderState => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $EatCartStateCopyWith<EatCartState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EatCartStateCopyWith<$Res> {
  factory $EatCartStateCopyWith(
          EatCartState value, $Res Function(EatCartState) then) =
      _$EatCartStateCopyWithImpl<$Res, EatCartState>;
  @useResult
  $Res call(
      {CartState cart,
      ValidateCartState validateCart,
      ConfirmOrderState confirmOrderState});

  $CartStateCopyWith<$Res> get cart;
  $ValidateCartStateCopyWith<$Res> get validateCart;
  $ConfirmOrderStateCopyWith<$Res> get confirmOrderState;
}

/// @nodoc
class _$EatCartStateCopyWithImpl<$Res, $Val extends EatCartState>
    implements $EatCartStateCopyWith<$Res> {
  _$EatCartStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? cart = null,
    Object? validateCart = null,
    Object? confirmOrderState = null,
  }) {
    return _then(_value.copyWith(
      cart: null == cart
          ? _value.cart
          : cart // ignore: cast_nullable_to_non_nullable
              as CartState,
      validateCart: null == validateCart
          ? _value.validateCart
          : validateCart // ignore: cast_nullable_to_non_nullable
              as ValidateCartState,
      confirmOrderState: null == confirmOrderState
          ? _value.confirmOrderState
          : confirmOrderState // ignore: cast_nullable_to_non_nullable
              as ConfirmOrderState,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CartStateCopyWith<$Res> get cart {
    return $CartStateCopyWith<$Res>(_value.cart, (value) {
      return _then(_value.copyWith(cart: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $ValidateCartStateCopyWith<$Res> get validateCart {
    return $ValidateCartStateCopyWith<$Res>(_value.validateCart, (value) {
      return _then(_value.copyWith(validateCart: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $ConfirmOrderStateCopyWith<$Res> get confirmOrderState {
    return $ConfirmOrderStateCopyWith<$Res>(_value.confirmOrderState, (value) {
      return _then(_value.copyWith(confirmOrderState: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_EatCartStateCopyWith<$Res>
    implements $EatCartStateCopyWith<$Res> {
  factory _$$_EatCartStateCopyWith(
          _$_EatCartState value, $Res Function(_$_EatCartState) then) =
      __$$_EatCartStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {CartState cart,
      ValidateCartState validateCart,
      ConfirmOrderState confirmOrderState});

  @override
  $CartStateCopyWith<$Res> get cart;
  @override
  $ValidateCartStateCopyWith<$Res> get validateCart;
  @override
  $ConfirmOrderStateCopyWith<$Res> get confirmOrderState;
}

/// @nodoc
class __$$_EatCartStateCopyWithImpl<$Res>
    extends _$EatCartStateCopyWithImpl<$Res, _$_EatCartState>
    implements _$$_EatCartStateCopyWith<$Res> {
  __$$_EatCartStateCopyWithImpl(
      _$_EatCartState _value, $Res Function(_$_EatCartState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? cart = null,
    Object? validateCart = null,
    Object? confirmOrderState = null,
  }) {
    return _then(_$_EatCartState(
      cart: null == cart
          ? _value.cart
          : cart // ignore: cast_nullable_to_non_nullable
              as CartState,
      validateCart: null == validateCart
          ? _value.validateCart
          : validateCart // ignore: cast_nullable_to_non_nullable
              as ValidateCartState,
      confirmOrderState: null == confirmOrderState
          ? _value.confirmOrderState
          : confirmOrderState // ignore: cast_nullable_to_non_nullable
              as ConfirmOrderState,
    ));
  }
}

/// @nodoc

class _$_EatCartState implements _EatCartState {
  _$_EatCartState(
      {this.cart = const CartState.fetchingCart(),
      this.validateCart = const ValidateCartState.validatingCart(),
      this.confirmOrderState = const ConfirmOrderState.nothing()});

  @override
  @JsonKey()
  final CartState cart;
  @override
  @JsonKey()
  final ValidateCartState validateCart;
  @override
  @JsonKey()
  final ConfirmOrderState confirmOrderState;

  @override
  String toString() {
    return 'EatCartState(cart: $cart, validateCart: $validateCart, confirmOrderState: $confirmOrderState)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EatCartState &&
            (identical(other.cart, cart) || other.cart == cart) &&
            (identical(other.validateCart, validateCart) ||
                other.validateCart == validateCart) &&
            (identical(other.confirmOrderState, confirmOrderState) ||
                other.confirmOrderState == confirmOrderState));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, cart, validateCart, confirmOrderState);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EatCartStateCopyWith<_$_EatCartState> get copyWith =>
      __$$_EatCartStateCopyWithImpl<_$_EatCartState>(this, _$identity);
}

abstract class _EatCartState implements EatCartState {
  factory _EatCartState(
      {final CartState cart,
      final ValidateCartState validateCart,
      final ConfirmOrderState confirmOrderState}) = _$_EatCartState;

  @override
  CartState get cart;
  @override
  ValidateCartState get validateCart;
  @override
  ConfirmOrderState get confirmOrderState;
  @override
  @JsonKey(ignore: true)
  _$$_EatCartStateCopyWith<_$_EatCartState> get copyWith =>
      throw _privateConstructorUsedError;
}
