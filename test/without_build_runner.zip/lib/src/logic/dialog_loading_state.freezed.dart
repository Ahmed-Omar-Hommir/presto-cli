// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dialog_loading_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ConfirmOrderState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() openDialog,
    required TResult Function() closeDialog,
    required TResult Function() nothing,
    required TResult Function() confirmed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? openDialog,
    TResult? Function()? closeDialog,
    TResult? Function()? nothing,
    TResult? Function()? confirmed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? openDialog,
    TResult Function()? closeDialog,
    TResult Function()? nothing,
    TResult Function()? confirmed,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(OpenDialog value) openDialog,
    required TResult Function(CloseDialog value) closeDialog,
    required TResult Function(Nothing value) nothing,
    required TResult Function(Confirmed value) confirmed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(OpenDialog value)? openDialog,
    TResult? Function(CloseDialog value)? closeDialog,
    TResult? Function(Nothing value)? nothing,
    TResult? Function(Confirmed value)? confirmed,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(OpenDialog value)? openDialog,
    TResult Function(CloseDialog value)? closeDialog,
    TResult Function(Nothing value)? nothing,
    TResult Function(Confirmed value)? confirmed,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ConfirmOrderStateCopyWith<$Res> {
  factory $ConfirmOrderStateCopyWith(
          ConfirmOrderState value, $Res Function(ConfirmOrderState) then) =
      _$ConfirmOrderStateCopyWithImpl<$Res, ConfirmOrderState>;
}

/// @nodoc
class _$ConfirmOrderStateCopyWithImpl<$Res, $Val extends ConfirmOrderState>
    implements $ConfirmOrderStateCopyWith<$Res> {
  _$ConfirmOrderStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$OpenDialogCopyWith<$Res> {
  factory _$$OpenDialogCopyWith(
          _$OpenDialog value, $Res Function(_$OpenDialog) then) =
      __$$OpenDialogCopyWithImpl<$Res>;
}

/// @nodoc
class __$$OpenDialogCopyWithImpl<$Res>
    extends _$ConfirmOrderStateCopyWithImpl<$Res, _$OpenDialog>
    implements _$$OpenDialogCopyWith<$Res> {
  __$$OpenDialogCopyWithImpl(
      _$OpenDialog _value, $Res Function(_$OpenDialog) _then)
      : super(_value, _then);
}

/// @nodoc

class _$OpenDialog implements OpenDialog {
  const _$OpenDialog();

  @override
  String toString() {
    return 'ConfirmOrderState.openDialog()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$OpenDialog);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() openDialog,
    required TResult Function() closeDialog,
    required TResult Function() nothing,
    required TResult Function() confirmed,
  }) {
    return openDialog();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? openDialog,
    TResult? Function()? closeDialog,
    TResult? Function()? nothing,
    TResult? Function()? confirmed,
  }) {
    return openDialog?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? openDialog,
    TResult Function()? closeDialog,
    TResult Function()? nothing,
    TResult Function()? confirmed,
    required TResult orElse(),
  }) {
    if (openDialog != null) {
      return openDialog();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(OpenDialog value) openDialog,
    required TResult Function(CloseDialog value) closeDialog,
    required TResult Function(Nothing value) nothing,
    required TResult Function(Confirmed value) confirmed,
  }) {
    return openDialog(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(OpenDialog value)? openDialog,
    TResult? Function(CloseDialog value)? closeDialog,
    TResult? Function(Nothing value)? nothing,
    TResult? Function(Confirmed value)? confirmed,
  }) {
    return openDialog?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(OpenDialog value)? openDialog,
    TResult Function(CloseDialog value)? closeDialog,
    TResult Function(Nothing value)? nothing,
    TResult Function(Confirmed value)? confirmed,
    required TResult orElse(),
  }) {
    if (openDialog != null) {
      return openDialog(this);
    }
    return orElse();
  }
}

abstract class OpenDialog implements ConfirmOrderState {
  const factory OpenDialog() = _$OpenDialog;
}

/// @nodoc
abstract class _$$CloseDialogCopyWith<$Res> {
  factory _$$CloseDialogCopyWith(
          _$CloseDialog value, $Res Function(_$CloseDialog) then) =
      __$$CloseDialogCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CloseDialogCopyWithImpl<$Res>
    extends _$ConfirmOrderStateCopyWithImpl<$Res, _$CloseDialog>
    implements _$$CloseDialogCopyWith<$Res> {
  __$$CloseDialogCopyWithImpl(
      _$CloseDialog _value, $Res Function(_$CloseDialog) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CloseDialog implements CloseDialog {
  const _$CloseDialog();

  @override
  String toString() {
    return 'ConfirmOrderState.closeDialog()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$CloseDialog);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() openDialog,
    required TResult Function() closeDialog,
    required TResult Function() nothing,
    required TResult Function() confirmed,
  }) {
    return closeDialog();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? openDialog,
    TResult? Function()? closeDialog,
    TResult? Function()? nothing,
    TResult? Function()? confirmed,
  }) {
    return closeDialog?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? openDialog,
    TResult Function()? closeDialog,
    TResult Function()? nothing,
    TResult Function()? confirmed,
    required TResult orElse(),
  }) {
    if (closeDialog != null) {
      return closeDialog();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(OpenDialog value) openDialog,
    required TResult Function(CloseDialog value) closeDialog,
    required TResult Function(Nothing value) nothing,
    required TResult Function(Confirmed value) confirmed,
  }) {
    return closeDialog(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(OpenDialog value)? openDialog,
    TResult? Function(CloseDialog value)? closeDialog,
    TResult? Function(Nothing value)? nothing,
    TResult? Function(Confirmed value)? confirmed,
  }) {
    return closeDialog?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(OpenDialog value)? openDialog,
    TResult Function(CloseDialog value)? closeDialog,
    TResult Function(Nothing value)? nothing,
    TResult Function(Confirmed value)? confirmed,
    required TResult orElse(),
  }) {
    if (closeDialog != null) {
      return closeDialog(this);
    }
    return orElse();
  }
}

abstract class CloseDialog implements ConfirmOrderState {
  const factory CloseDialog() = _$CloseDialog;
}

/// @nodoc
abstract class _$$NothingCopyWith<$Res> {
  factory _$$NothingCopyWith(_$Nothing value, $Res Function(_$Nothing) then) =
      __$$NothingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NothingCopyWithImpl<$Res>
    extends _$ConfirmOrderStateCopyWithImpl<$Res, _$Nothing>
    implements _$$NothingCopyWith<$Res> {
  __$$NothingCopyWithImpl(_$Nothing _value, $Res Function(_$Nothing) _then)
      : super(_value, _then);
}

/// @nodoc

class _$Nothing implements Nothing {
  const _$Nothing();

  @override
  String toString() {
    return 'ConfirmOrderState.nothing()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$Nothing);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() openDialog,
    required TResult Function() closeDialog,
    required TResult Function() nothing,
    required TResult Function() confirmed,
  }) {
    return nothing();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? openDialog,
    TResult? Function()? closeDialog,
    TResult? Function()? nothing,
    TResult? Function()? confirmed,
  }) {
    return nothing?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? openDialog,
    TResult Function()? closeDialog,
    TResult Function()? nothing,
    TResult Function()? confirmed,
    required TResult orElse(),
  }) {
    if (nothing != null) {
      return nothing();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(OpenDialog value) openDialog,
    required TResult Function(CloseDialog value) closeDialog,
    required TResult Function(Nothing value) nothing,
    required TResult Function(Confirmed value) confirmed,
  }) {
    return nothing(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(OpenDialog value)? openDialog,
    TResult? Function(CloseDialog value)? closeDialog,
    TResult? Function(Nothing value)? nothing,
    TResult? Function(Confirmed value)? confirmed,
  }) {
    return nothing?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(OpenDialog value)? openDialog,
    TResult Function(CloseDialog value)? closeDialog,
    TResult Function(Nothing value)? nothing,
    TResult Function(Confirmed value)? confirmed,
    required TResult orElse(),
  }) {
    if (nothing != null) {
      return nothing(this);
    }
    return orElse();
  }
}

abstract class Nothing implements ConfirmOrderState {
  const factory Nothing() = _$Nothing;
}

/// @nodoc
abstract class _$$ConfirmedCopyWith<$Res> {
  factory _$$ConfirmedCopyWith(
          _$Confirmed value, $Res Function(_$Confirmed) then) =
      __$$ConfirmedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ConfirmedCopyWithImpl<$Res>
    extends _$ConfirmOrderStateCopyWithImpl<$Res, _$Confirmed>
    implements _$$ConfirmedCopyWith<$Res> {
  __$$ConfirmedCopyWithImpl(
      _$Confirmed _value, $Res Function(_$Confirmed) _then)
      : super(_value, _then);
}

/// @nodoc

class _$Confirmed implements Confirmed {
  const _$Confirmed();

  @override
  String toString() {
    return 'ConfirmOrderState.confirmed()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$Confirmed);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() openDialog,
    required TResult Function() closeDialog,
    required TResult Function() nothing,
    required TResult Function() confirmed,
  }) {
    return confirmed();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? openDialog,
    TResult? Function()? closeDialog,
    TResult? Function()? nothing,
    TResult? Function()? confirmed,
  }) {
    return confirmed?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? openDialog,
    TResult Function()? closeDialog,
    TResult Function()? nothing,
    TResult Function()? confirmed,
    required TResult orElse(),
  }) {
    if (confirmed != null) {
      return confirmed();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(OpenDialog value) openDialog,
    required TResult Function(CloseDialog value) closeDialog,
    required TResult Function(Nothing value) nothing,
    required TResult Function(Confirmed value) confirmed,
  }) {
    return confirmed(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(OpenDialog value)? openDialog,
    TResult? Function(CloseDialog value)? closeDialog,
    TResult? Function(Nothing value)? nothing,
    TResult? Function(Confirmed value)? confirmed,
  }) {
    return confirmed?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(OpenDialog value)? openDialog,
    TResult Function(CloseDialog value)? closeDialog,
    TResult Function(Nothing value)? nothing,
    TResult Function(Confirmed value)? confirmed,
    required TResult orElse(),
  }) {
    if (confirmed != null) {
      return confirmed(this);
    }
    return orElse();
  }
}

abstract class Confirmed implements ConfirmOrderState {
  const factory Confirmed() = _$Confirmed;
}
