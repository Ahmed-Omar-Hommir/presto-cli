import 'package:dartz/dartz.dart';
import 'package:domain_models/domain_models.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'cart_address_state.freezed.dart';

@freezed
class CartAddressState with _$CartAddressState {
  factory CartAddressState({
    @Default(AddressList()) AddressList addresses,
  }) = _CartAddressState;
}
