import 'package:component_library/component_library.dart';
import 'package:domain_models/domain_models.dart';
import 'package:eat_cart/eat_cart.dart';
import 'package:eat_cart/src/l10n/eat_cart_localization.dart';
import 'package:eat_cart/src/logic/eat_cart_bloc.dart';
import 'package:eat_cart/src/widgets/presto_section.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ItemList extends StatelessWidget {
  const ItemList({Key? key, required this.cart}) : super(key: key);
  final EatCartDM cart;

  @override
  Widget build(BuildContext context) {
    final items = cart.items.items;
    final bloc = context.read<EatCartBloc>();
    return PrestoSection(
      contentPadding: EdgeInsets.zero,
      title: EatCartLocalization.of(context).itemListLabel,
      child: ListView.separated(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = items[index];
          return PrestoCartItem(
            name: item.name,
            description: PrestoEatCartItemDescription(
              toppings: item.toppings.values.map((v) => v.name).toList(),
              ingredients: item.ingredients.values.map((v) => v.name).toList(),
            ),
            price: item.totalPrice,
            imageUrl: item.image,
            quantity: item.quantity,
            isItemAvailable: item.isOpen,
            onIncreaseQuantity: (increasedQuantity) {
              bloc.add(ChangeQuantityEvent(
                item: item,
                newQuantity: increasedQuantity,
              ));
            },
            onDecreaseQuantity: (decreasedQuantity) {
              bloc.add(ChangeQuantityEvent(
                item: item,
                newQuantity: decreasedQuantity,
              ));
            },
            onTap: () {
              context.read<EatCartDelegate>().onTapUpdateItemCart(item);
            },
            onConfirmDeletion: () {
              bloc.add(DeleteItemEvent(item));
            },
          );
        },
        separatorBuilder: (context, index) => const PrestoDivider(),
        itemCount: items.length,
      ),
    );
  }
}
